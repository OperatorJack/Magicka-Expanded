Magicka Expanded - Summoning Pack

By: OperatorJack & RedFurryDemon

====Requirements====
Magicka Expanded 00 - Framework, 01 - Resource Pack

====Description====
This mod adds these new magic effects:

- Summon Goblin Grunt
- Summon Goblin Officer
- Summon Goblin Warchief
- Summon War Durzog
- Summon Hulking Fabricant
- Summon Imperfect
- Summon Draugr
- Summon Lich
- Summon Ogrim
- Summon Spriggan
- Summon Centurion Spider
- Summon Centurion Archer
- Summon Steam Centurion
- Summon Ash Ghoul
- Summon Ash Zombie
- Summon Ash Slave
- Summon Ascended Sleeper
- Call Werewolf (Note: Due to some mesh issues, the werewolf will not fight. This may be resolved in the future. For now, it is for roleplay purposes.)


All of these spells can be learned through spell tomes and spell grimoires. You can find the common spells at your local book seller, while more rare spells are found in loot in the wild.