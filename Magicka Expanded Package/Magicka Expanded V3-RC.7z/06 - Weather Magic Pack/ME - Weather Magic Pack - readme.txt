Magicka Expanded - Weather Magic Pack

By: OperatorJack & RedFurryDemon

====Requirements====
Magicka Expanded 00 - Framework, 01 - Resource Pack

====Description====
This mod adds these new weather magic effects:

- Weather: Blizzard
- Weather: Snow
- Weather: Thunderstorm
- Weather: Ashstorm
- Weather: Blightstorm
- Weather: Clear
- Weather: Cloudy
- Weather: Foggy
- Weather: Overcast
- Weather: Rain

All of these spells can be learned through spell tomes and spell grimoires. You can find the common spells at your local book seller, while more rare spells are found in loot in the wild.