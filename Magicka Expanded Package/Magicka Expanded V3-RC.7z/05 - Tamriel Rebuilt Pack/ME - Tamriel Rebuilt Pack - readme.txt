Magicka Expanded - Tamriel Rebuilt Pack

By: OperatorJack & RedFurryDemon

====Requirements====
Magicka Expanded 00 - Framework, 01 - Resource Pack, Tamriel Rebuilt

====Description====
This mod expands Magicka Expanded to use Tamriel Rebuilt leveled lists and adds new magic effects.

This mod adds these new teleportation magic effects:

Major Locations:
- Teleport to Akamora
- Teleport to Firewatch
- Teleport to Helnim
- Teleport to Necrom
- Teleport to Old Ebonheart
- Teleport to Port Telvannis

Minor Locations:
- Teleport to Alt Bosara
- Teleport to Bal Orya
- Teleport to Gah Sadrith
- Teleport to Gorne
- Teleport to Llothanis
- Teleport to Marog
- Teleport to Meralag
- Teleport to Tel Aranyon
- Teleport to Tel Mothriva
- Teleprot to Tel Muthada
- Teleport to Tel Ouada

This mod also adds these new summoning magic effects:
- Call Sabre Cat
- Call Wereboar
- Summon Alfiq
- Summon Armor Centurion Champion
- Summon Armor Centurion
- Summon Draugr Housecarl
- Summon Draugr Lord
- Summon Dridrea
- Summon Dridrea Monarch
- Summon Frost Lich
- Summon Giant
- Summon Goblin Shaman
- Summon Greater Lich
- Summon Lamia
- Summon Mammoth
- Summon Minotaur
- Summon Mud Golem
- Summon Parastylus
- Summon Plain Strider
- Summon Raki
- Summon Silt Strider
- Summon Sload
- Summon Swamp Troll
- Summon Welkynd Spirit
- Summon Velk
- Summon Vermai
- Summon Trebataur


All of these spells can be learned through spell tomes and spell grimoires. You can find the common spells at your local book seller, while more rare spells are found in loot in the wild.