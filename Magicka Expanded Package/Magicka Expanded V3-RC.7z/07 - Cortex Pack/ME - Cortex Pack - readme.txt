Magicka Expanded - Cortex Pack

By: OperatorJack & RedFurryDemon

====Requirements====
Magicka Expanded 00 - Framework, 01 - Resource Pack

====Description====
This mod adds these new magic effects:

- Clone
Clones the target and makes them fight alongside you for the effect duration. The effect's magnitude is the level of actor that can be cloned.

- Coalesce
When present in a spell, gives the caster control over the spell projectile during projectile flight.

- Mind Rip
Allows the caster to view the target's spells and steal one, if they are able to.

- Mind Scan
While active, lets the caster see the spells in other actors minds.

- Permutation
Summons a creature from Oblivion that is increasingly more powerful depending on the caster's conjuration and willpower.

- Soul Scrye
While active, lets the caster view the skills and condition of the target.

- Darkness
Enshrouds the target in darkness, dousing any lights within.

- Blink
Teleports the caster to the targeted location.

All of these spells can be learned through spell tomes and spell grimoires. You can find the common spells at your local book seller, while more rare spells are found in loot in the wild.