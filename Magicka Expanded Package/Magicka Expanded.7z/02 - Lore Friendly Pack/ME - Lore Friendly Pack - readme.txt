Magicka Expanded - Lore Friendly Pack

By: OperatorJack & RedFurryDemon

====Requirements====
Magicka Expanded 00 - Framework, 01 - Resource Pack

====Description====
This mod adds these new magic effects:

- Banish Daedra
- Bound Greaves
- Bound Pauldrons
- Bound Claymore
- Bound Club
- Bound Dai-Katana
- Bound Katana
- Bound Shortsword
- Bound Staff
- Bound Tanto
- Bound Wakizashi
- Bound Waraxe
- Bound Warhammer

All of these spells can be learned through spell tomes and spell grimoires. You can find the common spells at your local book seller, while more rare spells are found in loot in the wild.