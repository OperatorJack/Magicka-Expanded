Magicka Expanded - Teleportation Pack

By: OperatorJack & RedFurryDemon

====Requirements====
Magicka Expanded 00 - Framework, 01 - Resource Pack

====Description====
This mod adds these new magic effects:

- Teleport to Ald-Ruhn
- Teleport to Balmora
- Teleport to Ebonheart
- Teleport to Vivec
- Teleport to Caldera
- Teleport to Gnisis
- Teleport to Maar Gan
- Teleport to Molag Mar
- Teleport to Mournhold
- Teleport to Pelagiad
- Teleport to Suran
- Teleport to Tel Mora
- Teleport to Mournhold

All of these spells can be learned through spell tomes and spell grimoires. You can find the common spells at your local book seller, while more rare spells are found in loot in the wild.